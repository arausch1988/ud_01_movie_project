#Alexander's Favourite Movies:
This script shows Alexanders favourites movies in a webbrowser.

#Getting Started:

##A) Requirements (if you want to change Code):
    1) Please install Python 2.7.10 on your computer
    2) add Python modules webbrowser, os and re
    3) Download all files

##B) Run Movie
    1) open file **fresh_tomatoes.html** to see the website with Alexander's favourite Movies, you need an internet connection to play the movie trailers and the movie images



